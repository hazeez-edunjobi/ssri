SYNTHETIC Stage 2.5 schema-v2 template (16 channels). Not real data.
