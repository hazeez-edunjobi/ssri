SYNTHETIC Stage 2.5 template. Not real data. Shell demo only.
